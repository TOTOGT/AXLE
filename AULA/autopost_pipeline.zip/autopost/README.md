# AutoPost Pipeline
## Trend → Script → Voice → Video → Post
### G6 LLC · Pablo Nogueira Grossi · @guru.oenglish · @pablogrow2026

---

## What This Does

Every day at 10 AM your Vultr server:

1. **Scrapes** Google Trends + Reddit for viral AI / ESL / income topics
2. **Writes** a 30-45 second hook script using GPT-4o-mini (~$0.001/video)
3. **Voices** it using edge-tts — free Microsoft neural voices, no API cost
4. **Renders** a 1080x1920 vertical video with captions using FFmpeg — local, free
5. **Posts** to TikTok (@guru.oenglish), YouTube Shorts, and Instagram Reels (@pablogrow2026)

---

## Estimated Monthly Cost

| Item                    | Cost/month |
|-------------------------|------------|
| Vultr Cloud Compute      | ~$6        |
| OpenAI GPT-4o-mini (30 videos) | ~$0.03  |
| edge-tts voiceover      | Free       |
| FFmpeg rendering        | Free       |
| Pexels backgrounds      | Free       |
| **Total**               | **~$6/month** |

---

## Directory Structure

```
autopost/
├── run.py                    ← Master orchestrator (run this)
├── setup_vultr.sh            ← One-time server setup
├── config/
│   └── config.py             ← API keys, affiliate links, settings
├── scripts/
│   ├── 01_scrape_trends.py   ← Google Trends + Reddit scraper
│   ├── 02_generate_script.py ← GPT-4o-mini script writer
│   ├── 03_generate_voiceover.py ← edge-tts free voiceover
│   ├── 04_render_video.py    ← FFmpeg video renderer
│   └── 05_post_video.py      ← TikTok + YouTube + Instagram poster
├── assets/
│   └── backgrounds/          ← Downloaded background videos
├── output/                   ← Generated videos, scripts, audio
└── logs/                     ← Daily run logs
```

---

## Setup (One Time)

### Step 1: Create a Vultr server

- Go to vultr.com → Deploy → Cloud Compute
- OS: Ubuntu 22.04 LTS
- Size: $6/month (1 vCPU, 1GB RAM) — enough for this pipeline
- Location: New Jersey (closest to you)
- SSH Key: add your public key

### Step 2: SSH into your server

```bash
ssh root@your-vultr-ip
```

### Step 3: Upload and run the setup script

```bash
# On your Vultr server:
mkdir -p /home/claude/autopost
# Copy all files to the server, then:
chmod +x /home/claude/autopost/setup_vultr.sh
./home/claude/autopost/setup_vultr.sh
```

### Step 4: Fill in your API keys

Edit `/home/claude/autopost/config/config.py`:

```python
OPENAI_API_KEY      = "sk-..."           # platform.openai.com
TIKTOK_ACCESS_TOKEN = "..."              # developers.tiktok.com
INSTAGRAM_ACCESS_TOKEN = "..."           # developers.facebook.com
```

### Step 5: Get your API credentials

#### OpenAI (GPT-4o-mini for scripts)
1. Go to platform.openai.com → API Keys
2. Create key → add $5 credit (lasts months at $0.001/video)
3. Paste into config.py

#### TikTok Content Posting API
1. Go to developers.tiktok.com
2. Create app → Request "Content Posting API" permission
3. Generate user access token for @guru.oenglish
4. Paste into config.py

#### Instagram Graph API
1. Go to developers.facebook.com
2. Create app → Add "Instagram Graph API" product
3. Connect your @pablogrow2026 business account
4. Generate long-lived access token
5. Get your Instagram User ID:
   `curl "https://graph.facebook.com/me?access_token=YOUR_TOKEN"`
6. Paste both into config.py and run.py (IG_USER_ID)

#### YouTube Data API
1. Go to console.cloud.google.com
2. Create project → Enable "YouTube Data API v3"
3. OAuth 2.0 credentials → download client_secret.json
4. Run the auth setup: `python3 scripts/setup_youtube_auth.py`

#### Pexels (free background videos — optional)
1. Go to pexels.com/api → Get free API key
2. Paste into scripts/04_render_video.py

---

## Running the Pipeline

```bash
cd /home/claude/autopost
source venv/bin/activate

# Test — generates video but does NOT post
python3 run.py --dry-run

# Test with specific topic
python3 run.py --dry-run --topic "How to use Gemini AI to learn English"

# Live run — posts to all platforms
python3 run.py

# Check today's log
tail -f logs/run_$(date +%Y%m%d).log

# Check cron log
tail -f logs/cron.log
```

---

## Highest-Paying Affiliate Programs to Target

Add these to your bio link rotation in config.py:

| Program              | Commission    | Niche         | Sign up |
|----------------------|---------------|---------------|---------|
| Shopee Affiliate     | 2.5–12%/sale  | All products  | app.impact.com |
| Gumroad (your own)   | 100%          | ESL / books   | g6llc.gumroad.com |
| Jasper AI            | 30% recurring | AI writing    | jasper.ai/affiliates |
| Semrush              | $200/sale     | SEO tools     | semrush.com/affiliates |
| ClickBank (digital)  | 50–75%/sale   | Courses       | clickbank.com |
| Epidemic Sound       | $15/referral  | Music/creators| epidemicsound.com |
| NordVPN              | 40–100%       | Privacy tools | nordvpn.com/affiliates |
| Canva Pro            | $36/referral  | Design        | canva.com/affiliates |

---

## Cron Schedule

The pipeline runs automatically via cron:
```
0 10 * * *  →  10:00 AM UTC (6:00 AM Eastern) — posts before peak hours
```

To change the time:
```bash
crontab -e
# Change "0 10" to your preferred hour (UTC)
```

---

## Troubleshooting

**FFmpeg not found:**
```bash
apt-get install ffmpeg
```

**edge-tts fails:**
```bash
pip install edge-tts --upgrade
```

**Video too large for TikTok (>287MB):**
Lower the CRF in 04_render_video.py: change `-crf 23` to `-crf 28`

**Instagram requires public video URL:**
Make sure the video file server is running:
```bash
systemctl status autopost-server
```
Your server's public IP: `curl ifconfig.me`

---

© 2026 Pablo Nogueira Grossi / G6 LLC · Newark, NJ
ORCID 0009-0000-6496-2186 · grossiatwork@gmail.com
