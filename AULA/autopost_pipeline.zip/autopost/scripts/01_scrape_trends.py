"""
Step 1: Trend Scraper
Scrapes Google Trends and Reddit for viral AI / passive income / ESL keywords.
G6 LLC · Pablo Nogueira Grossi
"""

import requests
import json
import random
import logging
from datetime import datetime
from bs4 import BeautifulSoup
import sys
sys.path.append('/home/claude/autopost')
from config.config import NICHES

logging.basicConfig(
    filename='/home/claude/autopost/logs/trends.log',
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

# ── REDDIT SCRAPER ────────────────────────────────────────────
SUBREDDITS = [
    "SideHustle",
    "artificial",
    "learnprogramming",
    "passive_income",
    "AItools",
    "EnglishLearning",
    "digitalnomad",
    "AffiliateMarketing",
]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; AutoPostBot/1.0; +grossiatwork@gmail.com)"
}

def scrape_reddit_trends(subreddit: str, limit: int = 5) -> list[dict]:
    """Fetch top posts from a subreddit via the JSON API."""
    url = f"https://www.reddit.com/r/{subreddit}/hot.json?limit={limit}"
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        r.raise_for_status()
        posts = r.json()["data"]["children"]
        results = []
        for post in posts:
            d = post["data"]
            if d.get("score", 0) > 100:  # only posts with traction
                results.append({
                    "title":     d["title"],
                    "score":     d["score"],
                    "subreddit": subreddit,
                    "url":       f"https://reddit.com{d['permalink']}",
                })
        logging.info(f"Reddit r/{subreddit}: {len(results)} trending posts")
        return results
    except Exception as e:
        logging.warning(f"Reddit r/{subreddit} failed: {e}")
        return []


def scrape_google_trends_rss() -> list[str]:
    """Fetch daily trending searches from Google Trends RSS feed."""
    url = "https://trends.google.com/trends/trendingsearches/daily/rss?geo=US"
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(r.content, "xml")
        items = soup.find_all("title")[1:16]  # skip feed title
        trends = [item.text.strip() for item in items]
        logging.info(f"Google Trends: {len(trends)} trending searches")
        return trends
    except Exception as e:
        logging.warning(f"Google Trends RSS failed: {e}")
        return []


def filter_relevant_trends(trends: list[str]) -> list[str]:
    """Keep only trends relevant to our niches."""
    keywords = [
        "ai", "money", "income", "english", "learn", "earn", "passive",
        "tiktok", "instagram", "shopee", "affiliate", "tool", "free",
        "business", "online", "side", "hustle", "chatgpt", "gemini",
        "claude", "automation", "hack", "trick", "simple", "easy"
    ]
    relevant = []
    for t in trends:
        if any(kw in t.lower() for kw in keywords):
            relevant.append(t)
    return relevant


def get_best_trend() -> dict:
    """
    Main function — returns the single best trend to make a video about.
    Falls back to our predefined niches if scraping fails.
    """
    all_trends = []

    # 1. Google Trends
    google = scrape_google_trends_rss()
    relevant_google = filter_relevant_trends(google)
    for t in relevant_google:
        all_trends.append({"topic": t, "source": "google_trends", "score": 80})

    # 2. Reddit
    for sub in random.sample(SUBREDDITS, 3):  # 3 random subreddits per run
        posts = scrape_reddit_trends(sub, limit=5)
        for p in posts:
            if any(kw in p["title"].lower() for kw in ["ai", "money", "earn", "english", "income", "passive"]):
                all_trends.append({
                    "topic":  p["title"][:120],
                    "source": f"reddit_r/{sub}",
                    "score":  min(p["score"] // 10, 100),
                })

    # 3. Always add our own niches as fallback
    for niche in NICHES:
        all_trends.append({"topic": niche, "source": "curated_niche", "score": 60})

    if not all_trends:
        return {"topic": random.choice(NICHES), "source": "fallback", "score": 50}

    # Sort by score, pick from top 5 randomly for variety
    all_trends.sort(key=lambda x: x["score"], reverse=True)
    top5 = all_trends[:5]
    chosen = random.choice(top5)

    logging.info(f"Chosen trend: {chosen['topic']} (source: {chosen['source']})")
    print(f"[TREND] {chosen['topic']} via {chosen['source']}")
    return chosen


if __name__ == "__main__":
    trend = get_best_trend()
    print(json.dumps(trend, indent=2))
