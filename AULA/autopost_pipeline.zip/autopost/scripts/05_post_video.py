"""
Step 5: Auto-Poster
Uploads the rendered video to TikTok, YouTube Shorts, and Instagram Reels.
G6 LLC · Pablo Nogueira Grossi
"""

import os
import json
import logging
import requests
import time
import sys
sys.path.append('/home/claude/autopost')
from config.config import (
    TIKTOK_ACCESS_TOKEN,
    YOUTUBE_CLIENT_SECRET,
    INSTAGRAM_ACCESS_TOKEN,
    AFFILIATE_LINKS,
)

logging.basicConfig(
    filename='/home/claude/autopost/logs/posting.log',
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

# ── CAPTION BUILDER ───────────────────────────────────────────
HASHTAG_SETS = {
    "english":    "#LearnEnglish #ESL #EnglishTips #LearnEnglishOnline #English",
    "ai":         "#AITools #ArtificialIntelligence #GeminiAI #ChatGPT #AI",
    "income":     "#PassiveIncome #SideHustle #MakeMoneyOnline #OnlineIncome",
    "shopee":     "#Shopee #ShopeeAffiliate #OnlineShopping #AffiliateMarketing",
    "default":    "#LearnEnglish #AITools #SideHustle #DigitalLife #Newark",
}

def build_caption(script_data: dict) -> str:
    """Builds a post caption with the hook line + hashtags + CTA link."""
    lines   = script_data.get("lines", [])
    topic   = script_data.get("topic", "")
    link    = script_data.get("affiliate_link", AFFILIATE_LINKS["default"])

    # Use first line as the caption hook
    hook = lines[0] if lines else topic[:100]

    # Pick hashtags based on topic
    t = topic.lower()
    if "english" in t or "esl" in t:
        tags = HASHTAG_SETS["english"]
    elif "ai" in t or "gemini" in t or "tool" in t:
        tags = HASHTAG_SETS["ai"]
    elif "income" in t or "money" in t or "earn" in t:
        tags = HASHTAG_SETS["income"]
    elif "shopee" in t:
        tags = HASHTAG_SETS["shopee"]
    else:
        tags = HASHTAG_SETS["default"]

    caption = f"{hook}\n\n{tags}\n\n🔗 Link in bio → {link}"
    return caption


# ── TIKTOK UPLOADER ───────────────────────────────────────────
def post_to_tiktok(video_path: str, caption: str) -> dict:
    """
    Uploads a video to TikTok using the Content Posting API.
    Requires: TikTok for Developers account + Content Posting API access.
    Docs: https://developers.tiktok.com/doc/content-posting-api-get-started
    """
    if not TIKTOK_ACCESS_TOKEN:
        print("[TIKTOK] No access token — skipping")
        return {"status": "skipped", "reason": "no_token"}

    try:
        file_size = os.path.getsize(video_path)

        # Step 1: Initialize upload
        init_url = "https://open.tiktokapis.com/v2/post/publish/video/init/"
        headers = {
            "Authorization": f"Bearer {TIKTOK_ACCESS_TOKEN}",
            "Content-Type": "application/json; charset=UTF-8",
        }
        init_payload = {
            "post_info": {
                "title": caption[:150],  # TikTok caption limit
                "privacy_level": "PUBLIC_TO_EVERYONE",
                "disable_duet": False,
                "disable_comment": False,
                "disable_stitch": False,
                "video_cover_timestamp_ms": 1000,
            },
            "source_info": {
                "source": "FILE_UPLOAD",
                "video_size": file_size,
                "chunk_size": file_size,
                "total_chunk_count": 1,
            }
        }

        init_r = requests.post(init_url, headers=headers, json=init_payload, timeout=30)
        init_data = init_r.json()

        if init_r.status_code != 200:
            raise ValueError(f"TikTok init failed: {init_data}")

        upload_url = init_data["data"]["upload_url"]
        publish_id = init_data["data"]["publish_id"]

        # Step 2: Upload the video file
        with open(video_path, "rb") as f:
            video_bytes = f.read()

        upload_headers = {
            "Content-Type": "video/mp4",
            "Content-Range": f"bytes 0-{file_size - 1}/{file_size}",
            "Content-Length": str(file_size),
        }
        upload_r = requests.put(upload_url, data=video_bytes, headers=upload_headers, timeout=120)

        if upload_r.status_code not in [200, 201]:
            raise ValueError(f"TikTok upload failed: {upload_r.status_code}")

        logging.info(f"TikTok posted: publish_id={publish_id}")
        print(f"[TIKTOK] Posted: publish_id={publish_id}")
        return {"status": "success", "publish_id": publish_id, "platform": "tiktok"}

    except Exception as e:
        logging.error(f"TikTok post failed: {e}")
        print(f"[TIKTOK] Failed: {e}")
        return {"status": "error", "error": str(e), "platform": "tiktok"}


# ── YOUTUBE SHORTS UPLOADER ───────────────────────────────────
def post_to_youtube(video_path: str, title: str, description: str) -> dict:
    """
    Uploads to YouTube as a Short using the YouTube Data API v3.
    Requires: Google Cloud project + OAuth2 credentials.
    Docs: https://developers.google.com/youtube/v3/guides/uploading_a_video
    """
    if not YOUTUBE_CLIENT_SECRET:
        print("[YOUTUBE] No credentials — skipping")
        return {"status": "skipped", "reason": "no_credentials"}

    try:
        # Use google-auth-oauthlib for token refresh
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload

        # Load saved credentials (generated during first-time OAuth setup)
        creds_path = "/home/claude/autopost/config/youtube_token.json"
        if not os.path.exists(creds_path):
            raise FileNotFoundError(
                "YouTube OAuth token not found. Run setup_youtube_auth.py first."
            )

        creds = Credentials.from_authorized_user_file(creds_path)
        youtube = build("youtube", "v3", credentials=creds)

        request_body = {
            "snippet": {
                "title": title[:100],
                "description": description[:5000],
                "tags": ["LearnEnglish", "AI", "ESL", "SideHustle", "Shorts"],
                "categoryId": "27",  # Education
                "defaultLanguage": "en",
            },
            "status": {
                "privacyStatus": "public",
                "selfDeclaredMadeForKids": False,
            }
        }

        media = MediaFileUpload(video_path, mimetype="video/mp4", resumable=True)
        request = youtube.videos().insert(
            part="snippet,status",
            body=request_body,
            media_body=media,
        )

        response = None
        while response is None:
            _, response = request.next_chunk()

        video_id = response.get("id")
        url = f"https://youtube.com/shorts/{video_id}"
        logging.info(f"YouTube Short posted: {url}")
        print(f"[YOUTUBE] Posted: {url}")
        return {"status": "success", "video_id": video_id, "url": url, "platform": "youtube"}

    except Exception as e:
        logging.error(f"YouTube post failed: {e}")
        print(f"[YOUTUBE] Failed: {e}")
        return {"status": "error", "error": str(e), "platform": "youtube"}


# ── INSTAGRAM REELS UPLOADER ──────────────────────────────────
def post_to_instagram(video_path: str, caption: str, ig_user_id: str) -> dict:
    """
    Uploads a Reel to Instagram using the Graph API.
    Requires: Meta Business account + Instagram Graph API access token.
    Docs: https://developers.facebook.com/docs/instagram-api/guides/reels
    """
    if not INSTAGRAM_ACCESS_TOKEN:
        print("[INSTAGRAM] No access token — skipping")
        return {"status": "skipped", "reason": "no_token"}

    try:
        graph_url = "https://graph.facebook.com/v19.0"

        # Step 1: Upload video to a hosting URL first
        # Instagram requires a public URL — upload to your Vultr server's public IP
        # Or use a temporary upload service
        # For simplicity, we use the resumable upload endpoint

        # Step 1: Create media container
        container_url = f"{graph_url}/{ig_user_id}/media"
        container_params = {
            "media_type": "REELS",
            "video_url": f"http://your-vultr-ip/videos/{os.path.basename(video_path)}",
            "caption": caption[:2200],  # Instagram caption limit
            "share_to_feed": "true",
            "access_token": INSTAGRAM_ACCESS_TOKEN,
        }

        container_r = requests.post(container_url, data=container_params, timeout=60)
        container_data = container_r.json()

        if "id" not in container_data:
            raise ValueError(f"Container creation failed: {container_data}")

        container_id = container_data["id"]

        # Step 2: Wait for video processing
        print(f"[INSTAGRAM] Processing video (container_id={container_id})...")
        for _ in range(12):  # Wait up to 2 minutes
            time.sleep(10)
            status_r = requests.get(
                f"{graph_url}/{container_id}",
                params={"fields": "status_code", "access_token": INSTAGRAM_ACCESS_TOKEN}
            )
            status = status_r.json().get("status_code")
            if status == "FINISHED":
                break
            elif status == "ERROR":
                raise ValueError("Instagram video processing failed")
            print(f"[INSTAGRAM] Status: {status}")

        # Step 3: Publish the container
        publish_url = f"{graph_url}/{ig_user_id}/media_publish"
        publish_r = requests.post(publish_url, data={
            "creation_id": container_id,
            "access_token": INSTAGRAM_ACCESS_TOKEN,
        }, timeout=30)

        publish_data = publish_r.json()
        post_id = publish_data.get("id")

        logging.info(f"Instagram Reel posted: {post_id}")
        print(f"[INSTAGRAM] Posted: post_id={post_id}")
        return {"status": "success", "post_id": post_id, "platform": "instagram"}

    except Exception as e:
        logging.error(f"Instagram post failed: {e}")
        print(f"[INSTAGRAM] Failed: {e}")
        return {"status": "error", "error": str(e), "platform": "instagram"}


def post_everywhere(video_path: str, script_data: dict, ig_user_id: str = "") -> dict:
    """Post to all platforms and return results."""
    caption   = build_caption(script_data)
    topic     = script_data.get("topic", "Content")
    title     = f"{topic[:90]} #Shorts"

    results = {}

    print(f"\n[POSTING] Caption preview:\n{caption[:200]}\n")

    results["tiktok"]    = post_to_tiktok(video_path, caption)
    results["youtube"]   = post_to_youtube(video_path, title, caption)
    results["instagram"] = post_to_instagram(video_path, caption, ig_user_id)

    successes = sum(1 for r in results.values() if r.get("status") == "success")
    print(f"\n[POSTING] Done — {successes}/3 platforms posted successfully")
    return results


if __name__ == "__main__":
    # Test caption generation
    test_data = {
        "topic": "How to use Gemini AI to learn English",
        "lines": ["Nobody told me this about AI and English."],
        "affiliate_link": "https://g6llc.gumroad.com",
    }
    caption = build_caption(test_data)
    print("Test caption:\n")
    print(caption)
