"""
Step 3: Voiceover Generator
Uses edge-tts (free Microsoft neural voices) to convert the script to audio.
No API cost. Runs locally on Vultr server.
G6 LLC · Pablo Nogueira Grossi
"""

import asyncio
import edge_tts
import logging
import json
import os
import sys
sys.path.append('/home/claude/autopost')
from config.config import VOICE, OUTPUT_DIR

logging.basicConfig(
    filename='/home/claude/autopost/logs/voiceover.log',
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

# ── AVAILABLE VOICES ─────────────────────────────────────────
# Free Microsoft neural voices — choose based on your brand
VOICES = {
    # English male voices
    "en_us_guy":       "en-US-GuyNeural",        # Clear, authoritative — default
    "en_us_davis":     "en-US-DavisNeural",       # Warm, conversational
    "en_us_tony":      "en-US-TonyNeural",        # Energetic
    # English female voices
    "en_us_jenny":     "en-US-JennyNeural",       # Friendly, clear
    "en_us_aria":      "en-US-AriaNeural",        # Natural, warm
    # British English
    "en_gb_ryan":      "en-GB-RyanNeural",        # Professional
    # Portuguese (for bilingual content)
    "pt_br_antonio":   "pt-BR-AntonioNeural",     # Brazilian Portuguese male
    "pt_br_francisca": "pt-BR-FranciscaNeural",   # Brazilian Portuguese female
    # Spanish (for your Latino audience)
    "es_us_alvaro":    "es-US-AlonsoNeural",      # US Spanish male
}


async def generate_voiceover(
    text: str,
    output_path: str,
    voice: str = VOICE,
    rate: str = "+0%",     # Speed: "+10%" faster, "-10%" slower
    pitch: str = "+0Hz",   # Pitch adjustment
) -> str:
    """
    Converts text to an MP3 voiceover file using edge-tts.
    Completely free — uses Microsoft's neural TTS via edge browser protocol.
    Returns the output path.
    """
    communicate = edge_tts.Communicate(
        text=text,
        voice=voice,
        rate=rate,
        pitch=pitch,
    )

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    await communicate.save(output_path)

    file_size = os.path.getsize(output_path) // 1024
    logging.info(f"Voiceover saved: {output_path} ({file_size}KB, voice={voice})")
    print(f"[VOICE] Saved {file_size}KB audio → {output_path}")
    return output_path


def generate_voiceover_sync(
    text: str,
    output_path: str,
    voice: str = VOICE,
    rate: str = "+5%",
) -> str:
    """Synchronous wrapper for the async generate function."""
    return asyncio.run(generate_voiceover(text, output_path, voice, rate))


def prepare_script_for_tts(script_lines: list[str]) -> str:
    """
    Cleans and formats script lines for natural TTS delivery.
    Adds pauses between lines using SSML-style markers.
    """
    # Join lines with a short pause
    text_parts = []
    for line in script_lines:
        line = line.strip()
        if not line:
            continue
        # Remove any markdown or special characters
        line = line.replace('*', '').replace('#', '').replace('_', '')
        # Add a natural pause after each line
        text_parts.append(line)

    # Join with ". " to create natural pauses between lines
    full_text = '. '.join(text_parts)
    # Clean up double periods
    full_text = full_text.replace('.. ', '. ').replace('?.', '?').replace('!.', '!')
    return full_text


async def list_available_voices(lang_filter: str = "en-") -> None:
    """Utility: print all available edge-tts voices for a language."""
    voices = await edge_tts.list_voices()
    for v in voices:
        if lang_filter.lower() in v["ShortName"].lower():
            print(f"  {v['ShortName']:40s} {v['Gender']:8s} {v['Locale']}")


if __name__ == "__main__":
    import sys

    # List voices mode
    if len(sys.argv) > 1 and sys.argv[1] == "--list-voices":
        asyncio.run(list_available_voices())
        sys.exit(0)

    # Test voiceover generation
    test_script = {
        "lines": [
            "Nobody told me this about learning English with AI.",
            "Most people waste hours on grammar rules that don't matter.",
            "The fastest way to learn is to use AI to talk, not study.",
            "Gemini and Claude can be your free speaking partner, any time.",
            "Click the link in my bio to start today.",
        ]
    }

    text = prepare_script_for_tts(test_script["lines"])
    print(f"[TTS INPUT] {text[:200]}...")

    out = f"{OUTPUT_DIR}/test_voiceover.mp3"
    result = generate_voiceover_sync(text, out)
    print(f"[DONE] Voiceover at: {result}")
