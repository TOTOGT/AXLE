"""
Step 4: Video Renderer
Uses FFmpeg to combine background video + voiceover + burned-in captions
into a 1080x1920 (9:16) vertical video. Zero API cost — runs locally.
G6 LLC · Pablo Nogueira Grossi
"""

import subprocess
import os
import json
import random
import logging
import requests
import sys
sys.path.append('/home/claude/autopost')
from config.config import (
    VIDEO_WIDTH, VIDEO_HEIGHT, VIDEO_FPS, VIDEO_DURATION,
    CAPTION_FONT, CAPTION_SIZE, CAPTION_COLOR, CAPTION_STROKE,
    CAPTION_STROKE_WIDTH, BACKGROUNDS_DIR, OUTPUT_DIR
)

logging.basicConfig(
    filename='/home/claude/autopost/logs/render.log',
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

# ── FREE BACKGROUND VIDEO SOURCES ────────────────────────────
# Pexels API is free — get a key at pexels.com/api/
PEXELS_API_KEY = "your-pexels-api-key"

BACKGROUND_SEARCH_TERMS = [
    "city timelapse",
    "nature abstract",
    "ocean waves",
    "technology abstract",
    "coffee shop",
    "library books",
    "math equations",
    "space galaxy",
    "rain window",
    "fire flames",
]

# Fallback: use these free royalty-free background URLs
FALLBACK_BACKGROUNDS = [
    "https://www.pexels.com/download/video/3571264/",   # abstract loop
    "https://www.pexels.com/download/video/4812205/",   # particles
    "https://www.pexels.com/download/video/3129671/",   # city night
]


def download_background_video(search_term: str = None, output_path: str = None) -> str:
    """
    Downloads a free background video from Pexels.
    Falls back to a local file if download fails.
    """
    os.makedirs(BACKGROUNDS_DIR, exist_ok=True)

    # Check if we already have downloaded backgrounds
    existing = [f for f in os.listdir(BACKGROUNDS_DIR) if f.endswith('.mp4')]
    if existing and random.random() > 0.3:  # 70% chance to reuse existing
        chosen = random.choice(existing)
        path = os.path.join(BACKGROUNDS_DIR, chosen)
        print(f"[BG] Reusing existing background: {chosen}")
        return path

    if not search_term:
        search_term = random.choice(BACKGROUND_SEARCH_TERMS)

    if output_path is None:
        safe_term = search_term.replace(' ', '_')[:20]
        output_path = os.path.join(BACKGROUNDS_DIR, f"bg_{safe_term}.mp4")

    # Try Pexels API
    if PEXELS_API_KEY != "your-pexels-api-key":
        try:
            headers = {"Authorization": PEXELS_API_KEY}
            r = requests.get(
                f"https://api.pexels.com/videos/search?query={search_term}&per_page=5&orientation=portrait",
                headers=headers, timeout=15
            )
            data = r.json()
            videos = data.get("videos", [])
            if videos:
                video = random.choice(videos)
                # Pick the HD file
                files = sorted(video["video_files"], key=lambda x: x.get("height", 0), reverse=True)
                hd_file = next((f for f in files if f.get("height", 0) >= 720), files[0])
                url = hd_file["link"]
                video_r = requests.get(url, timeout=60, stream=True)
                with open(output_path, 'wb') as f:
                    for chunk in video_r.iter_content(chunk_size=8192):
                        f.write(chunk)
                print(f"[BG] Downloaded from Pexels: {output_path}")
                return output_path
        except Exception as e:
            logging.warning(f"Pexels download failed: {e}")

    # Fallback: generate a simple colored gradient background using FFmpeg
    print("[BG] Generating gradient background (Pexels key not set)")
    colors = ["0x1a2744", "0x2d5a27", "0x3a4f7a", "0x6c3483", "0x784212"]
    color = random.choice(colors)
    cmd = [
        "ffmpeg", "-y",
        "-f", "lavfi",
        "-i", f"color=c={color}:size={VIDEO_WIDTH}x{VIDEO_HEIGHT}:rate={VIDEO_FPS}:duration={VIDEO_DURATION}",
        "-vf", f"noise=alls=8:allf=t",
        output_path
    ]
    subprocess.run(cmd, capture_output=True)
    return output_path


def build_caption_filter(lines: list[str], audio_duration: float) -> str:
    """
    Builds an FFmpeg drawtext filter that shows each caption line
    in sequence, timed to the audio duration.
    """
    if not lines:
        return ""

    time_per_line = audio_duration / len(lines)
    filters = []

    for i, line in enumerate(lines):
        start_t = i * time_per_line
        end_t = (i + 1) * time_per_line

        # Escape special characters for FFmpeg
        safe_line = (line
                     .replace("'", "\\'")
                     .replace(":", "\\:")
                     .replace(",", "\\,")
                     .replace("[", "\\[")
                     .replace("]", "\\]"))

        # Two passes: stroke (black) + fill (white) for readability
        stroke_filter = (
            f"drawtext=text='{safe_line}'"
            f":fontfile=/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"
            f":fontsize={CAPTION_SIZE}"
            f":fontcolor=black"
            f":borderw={CAPTION_STROKE_WIDTH + 4}"
            f":bordercolor=black"
            f":x=(w-text_w)/2"
            f":y=(h*0.75)"
            f":line_spacing=8"
            f":enable='between(t,{start_t:.2f},{end_t:.2f})'"
        )

        fill_filter = (
            f"drawtext=text='{safe_line}'"
            f":fontfile=/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"
            f":fontsize={CAPTION_SIZE}"
            f":fontcolor=white"
            f":borderw={CAPTION_STROKE_WIDTH}"
            f":bordercolor=black"
            f":x=(w-text_w)/2"
            f":y=(h*0.75)"
            f":line_spacing=8"
            f":enable='between(t,{start_t:.2f},{end_t:.2f})'"
        )

        filters.extend([stroke_filter, fill_filter])

    return ",".join(filters)


def get_audio_duration(audio_path: str) -> float:
    """Get the duration of an audio file using ffprobe."""
    try:
        result = subprocess.run([
            "ffprobe", "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            audio_path
        ], capture_output=True, text=True, timeout=10)
        return float(result.stdout.strip())
    except Exception:
        return VIDEO_DURATION


def render_video(
    background_path: str,
    audio_path: str,
    script_lines: list[str],
    output_path: str,
    topic: str = "",
) -> str:
    """
    Main render function.
    Combines background + audio + captions → final 9:16 video.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    audio_duration = get_audio_duration(audio_path)
    print(f"[RENDER] Audio duration: {audio_duration:.1f}s")

    caption_filter = build_caption_filter(script_lines, audio_duration)

    # Build the FFmpeg command
    # -stream_loop -1 loops the background video to match audio length
    vf_parts = [
        f"scale={VIDEO_WIDTH}:{VIDEO_HEIGHT}:force_original_aspect_ratio=increase",
        f"crop={VIDEO_WIDTH}:{VIDEO_HEIGHT}",
        "format=yuv420p",
    ]

    if caption_filter:
        vf_parts.append(caption_filter)

    vf = ",".join(vf_parts)

    cmd = [
        "ffmpeg", "-y",
        "-stream_loop", "-1",
        "-i", background_path,         # input 0: background video (looped)
        "-i", audio_path,              # input 1: voiceover audio
        "-vf", vf,                     # video filters (scale, crop, captions)
        "-c:v", "libx264",
        "-preset", "fast",
        "-crf", "23",                  # quality: 0=lossless, 51=worst. 23 is good.
        "-c:a", "aac",
        "-b:a", "128k",
        "-t", str(audio_duration + 0.5),  # trim to audio length + 0.5s buffer
        "-r", str(VIDEO_FPS),
        "-movflags", "+faststart",     # web optimized
        output_path
    ]

    print(f"[RENDER] Running FFmpeg...")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

    if result.returncode != 0:
        logging.error(f"FFmpeg failed: {result.stderr[-500:]}")
        raise RuntimeError(f"FFmpeg render failed:\n{result.stderr[-300:]}")

    file_size = os.path.getsize(output_path) // (1024 * 1024)
    logging.info(f"Video rendered: {output_path} ({file_size}MB)")
    print(f"[RENDER] Done → {output_path} ({file_size}MB)")
    return output_path


if __name__ == "__main__":
    # Test render with placeholder files
    import datetime

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output = f"{OUTPUT_DIR}/test_video_{timestamp}.mp4"

    bg = download_background_video("technology abstract")
    print(f"Background: {bg}")

    # For testing, we need a real audio file
    test_audio = f"{OUTPUT_DIR}/test_voiceover.mp3"
    if not os.path.exists(test_audio):
        print("[RENDER] Run 03_generate_voiceover.py first to create test audio")
        sys.exit(1)

    test_lines = [
        "Nobody told me this about AI and English.",
        "Most people study grammar for years.",
        "But conversation is the only thing that matters.",
        "Use AI to practice every single day.",
        "Free tools. Link in bio.",
    ]

    render_video(bg, test_audio, test_lines, output, "AI English learning test")
    print(f"Test video: {output}")
