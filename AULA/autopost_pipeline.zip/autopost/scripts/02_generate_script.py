"""
Step 2: AI Script Generator
Uses GPT-4o-mini to write a 30-45 second viral video script from a trend.
G6 LLC · Pablo Nogueira Grossi
"""

import openai
import json
import logging
import re
import sys
sys.path.append('/home/claude/autopost')
from config.config import OPENAI_API_KEY, BRAND_VOICE, AFFILIATE_LINKS

logging.basicConfig(
    filename='/home/claude/autopost/logs/scripts.log',
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

openai.api_key = OPENAI_API_KEY


# ── SCRIPT TEMPLATES ─────────────────────────────────────────
# Different formats for variety — rotate to avoid repetition

SCRIPT_TEMPLATES = {

    "hook_value_cta": """
Write a 30-second TikTok/Reels script about: {topic}

Format:
- HOOK (line 1): A surprising fact or bold question. MAX 8 words. No emojis.
- BODY (3-4 lines): One new idea per line. Max 10 words each. Plain English.
- CTA (last line): Tell them to click the link in bio. Max 8 words.

Rules:
- Write for adult ESL learners — clear, simple vocabulary (B1-B2 level)
- No hashtags. No "Hey guys". No filler words.
- Sound like a smart friend, not a salesperson.
- Total: 6 lines maximum.

{brand_voice}

Topic: {topic}
Affiliate focus: {affiliate_focus}
""",

    "story_reveal": """
Write a 45-second short video script using the "secret reveal" format about: {topic}

Format:
- LINE 1 (hook): "Nobody told me this about [topic]..." — max 8 words
- LINE 2-3: Build tension — what most people get wrong
- LINE 4-5: The reveal — the actual useful insight
- LINE 6: CTA — link in bio for more

Rules:
- B1-B2 English level — global audience
- Each line max 12 words
- Conversational, no corporate language

{brand_voice}

Topic: {topic}
""",

    "list_format": """
Write a "3 things you didn't know" script about: {topic}

Format:
- Hook: "3 things about [topic] that will change how you..." — 8 words max
- Thing 1: short, punchy, surprising
- Thing 2: practical, actionable
- Thing 3: most valuable, save for last
- CTA: link in bio

Rules:
- B1-B2 English — clear, no jargon
- Each point = 1-2 sentences max
- End strong — the best point is always last

{brand_voice}
""",

}


def generate_script(trend: dict) -> dict:
    """
    Takes a trend dict {topic, source, score} and returns a full script dict.
    Costs approximately $0.001 per call with gpt-4o-mini.
    """
    topic = trend["topic"]

    # Pick affiliate link based on topic content
    affiliate_focus = AFFILIATE_LINKS["default"]
    if "shopee" in topic.lower():
        affiliate_focus = AFFILIATE_LINKS["shopee"]
    elif "english" in topic.lower() or "esl" in topic.lower():
        affiliate_focus = AFFILIATE_LINKS["course"]
    elif "ai" in topic.lower() or "tool" in topic.lower():
        affiliate_focus = AFFILIATE_LINKS.get("ai_tools", AFFILIATE_LINKS["default"])

    # Rotate templates for variety
    import random
    template_name = random.choice(list(SCRIPT_TEMPLATES.keys()))
    template = SCRIPT_TEMPLATES[template_name]

    prompt = template.format(
        topic=topic,
        brand_voice=BRAND_VOICE,
        affiliate_focus=affiliate_focus
    )

    try:
        response = openai.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": BRAND_VOICE},
                {"role": "user",   "content": prompt}
            ],
            max_tokens=300,
            temperature=0.85,
        )

        raw_script = response.choices[0].message.content.strip()

        # Clean up — remove any lines starting with "HOOK:", "BODY:", "CTA:", etc.
        lines = []
        for line in raw_script.split('\n'):
            line = line.strip()
            # Remove label prefixes like "HOOK:", "LINE 1:", "Thing 1:", etc.
            line = re.sub(r'^(HOOK|BODY|CTA|LINE \d+|Thing \d+|Point \d+):\s*', '', line, flags=re.IGNORECASE)
            if line and not line.startswith('#'):
                lines.append(line)

        clean_script = '\n'.join(lines)

        result = {
            "topic":          topic,
            "source":         trend.get("source", "unknown"),
            "template":       template_name,
            "script":         clean_script,
            "lines":          lines,
            "affiliate_link": affiliate_focus,
            "word_count":     len(clean_script.split()),
            "model":          "gpt-4o-mini",
        }

        logging.info(f"Script generated: {topic[:50]} — {len(lines)} lines, {result['word_count']} words")
        print(f"[SCRIPT] Generated {len(lines)}-line script for: {topic[:60]}")
        return result

    except Exception as e:
        logging.error(f"Script generation failed: {e}")
        # Fallback script
        fallback = {
            "topic":          topic,
            "source":         "fallback",
            "template":       "fallback",
            "script":         f"Did you know this about {topic}?\nMost people miss this completely.\nThe secret is simpler than you think.\nClick the link in my bio to learn more.",
            "lines":          [f"Did you know this about {topic}?", "Most people miss this completely.", "The secret is simpler than you think.", "Click the link in my bio."],
            "affiliate_link": AFFILIATE_LINKS["default"],
            "word_count":     25,
            "model":          "fallback",
        }
        return fallback


def save_script(script_data: dict, output_path: str) -> None:
    """Save script to JSON for the next pipeline step."""
    with open(output_path, 'w') as f:
        json.dump(script_data, f, indent=2, ensure_ascii=False)
    print(f"[SCRIPT] Saved to {output_path}")


if __name__ == "__main__":
    # Test with a sample trend
    test_trend = {"topic": "How to use Gemini AI to learn English faster", "source": "test", "score": 90}
    result = generate_script(test_trend)
    print("\n--- GENERATED SCRIPT ---")
    print(result["script"])
    print(f"\nAffiliate link: {result['affiliate_link']}")
