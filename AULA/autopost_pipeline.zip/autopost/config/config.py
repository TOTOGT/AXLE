"""
AutoPost Pipeline — Configuration
G6 LLC · Pablo Nogueira Grossi · Newark, NJ
"""

# ── API KEYS (fill these in on your Vultr server) ────────────
OPENAI_API_KEY    = "sk-..."          # openai.com — use gpt-4o-mini
TIKTOK_ACCESS_TOKEN = ""              # from TikTok for Developers
YOUTUBE_CLIENT_SECRET = ""            # from Google Cloud Console
INSTAGRAM_ACCESS_TOKEN = ""           # from Meta for Developers

# ── YOUR AFFILIATE LINKS (link-in-bio targets) ───────────────
# Rotate these — one per video — track which converts best
AFFILIATE_LINKS = {
    "default":    "https://g6llc.gumroad.com",           # Hour House membership
    "shopee":     "https://shope.ee/your-affiliate-id",  # Shopee affiliate
    "ai_tools":   "https://your-affiliate-link.com",     # AI tool affiliate
    "course":     "https://g6llc.gumroad.com",           # ESL course
}

# ── CONTENT STRATEGY ─────────────────────────────────────────
NICHES = [
    "AI tools for beginners",
    "Learn English with AI",
    "Make money online with AI",
    "Digital entrepreneurship for immigrants",
    "Shopee affiliate income",
    "Passive income with content creation",
    "English grammar tips",
    "How to use Gemini AI",
    "Instagram Reels strategy",
    "WorldQuant IQC competition",
]

# Your brand identity — injected into every script prompt
BRAND_VOICE = """
You are Pablo Grossi — researcher, teacher, and ESL content creator in Newark NJ.
Your audience: adult immigrants learning English and building online income.
Your tone: honest, warm, direct. No hype. Real value first.
Your hook style: start with a surprising fact or a question. Under 8 words.
"""

# ── VIDEO SETTINGS ───────────────────────────────────────────
VIDEO_WIDTH     = 1080
VIDEO_HEIGHT    = 1920   # 9:16 vertical
VIDEO_FPS       = 30
VIDEO_DURATION  = 45     # seconds — optimal for Reels/TikTok/Shorts
CAPTION_FONT    = "Arial"
CAPTION_SIZE    = 52
CAPTION_COLOR   = "white"
CAPTION_STROKE  = "black"
CAPTION_STROKE_WIDTH = 3
VOICE           = "en-US-GuyNeural"   # edge-tts voice — sounds natural

# ── POSTING SCHEDULE (cron format) ───────────────────────────
# Post once daily at 10:00 AM Eastern
CRON_SCHEDULE   = "0 10 * * *"
PEAK_HOURS      = [9, 10, 11, 18, 19, 20]  # fallback manual schedule

# ── FILE PATHS ───────────────────────────────────────────────
ASSETS_DIR      = "/home/claude/autopost/assets"
OUTPUT_DIR      = "/home/claude/autopost/output"
LOGS_DIR        = "/home/claude/autopost/logs"
BACKGROUNDS_DIR = "/home/claude/autopost/assets/backgrounds"
FONTS_DIR       = "/home/claude/autopost/assets/fonts"
