#!/bin/bash
# AutoPost Pipeline — Vultr Server Setup Script
# Run once after creating your Vultr Ubuntu 22.04 instance:
#   chmod +x setup_vultr.sh && ./setup_vultr.sh
# G6 LLC · Pablo Nogueira Grossi · Newark, NJ

set -e  # Exit on any error

echo ""
echo "=================================================="
echo "  AutoPost Pipeline — Vultr Server Setup"
echo "  G6 LLC · Newark, NJ"
echo "=================================================="
echo ""

# ── SYSTEM UPDATE ─────────────────────────────────────────────
echo "[1/8] Updating system packages..."
apt-get update -qq && apt-get upgrade -y -qq

# ── PYTHON & PIP ─────────────────────────────────────────────
echo "[2/8] Installing Python 3.11 and pip..."
apt-get install -y -qq python3.11 python3-pip python3.11-venv

# ── FFMPEG ────────────────────────────────────────────────────
echo "[3/8] Installing FFmpeg..."
apt-get install -y -qq ffmpeg
ffmpeg -version | head -1

# ── FONTS ─────────────────────────────────────────────────────
echo "[4/8] Installing fonts for captions..."
apt-get install -y -qq fonts-liberation fonts-dejavu-core
fc-cache -f -v > /dev/null 2>&1

# ── PYTHON VIRTUALENV ─────────────────────────────────────────
echo "[5/8] Creating Python virtual environment..."
cd /home/claude/autopost
python3.11 -m venv venv
source venv/bin/activate

# ── PYTHON PACKAGES ───────────────────────────────────────────
echo "[6/8] Installing Python packages..."
pip install --upgrade pip -q

pip install -q \
  openai==1.35.0 \
  edge-tts==6.1.9 \
  requests==2.31.0 \
  beautifulsoup4==4.12.3 \
  lxml==5.2.2 \
  google-auth==2.29.0 \
  google-auth-oauthlib==1.2.0 \
  google-api-python-client==2.131.0 \
  moviepy==1.0.3 \
  Pillow==10.3.0 \
  playwright==1.44.0

# Install Playwright browsers (for fallback posting via browser automation)
python3 -m playwright install chromium --with-deps

echo ""
echo "Installed packages:"
pip list | grep -E "openai|edge|requests|beautifulsoup|google|moviepy|Pillow|playwright"

# ── PROJECT DIRECTORIES ───────────────────────────────────────
echo "[7/8] Creating project directories..."
mkdir -p /home/claude/autopost/{scripts,assets,output,logs,config}
mkdir -p /home/claude/autopost/assets/{backgrounds,fonts}
mkdir -p /home/claude/autopost/output

# Create __init__.py files for Python imports
touch /home/claude/autopost/__init__.py
touch /home/claude/autopost/scripts/__init__.py
touch /home/claude/autopost/config/__init__.py

# ── CRON JOB ─────────────────────────────────────────────────
echo "[8/8] Setting up cron job (daily at 10:00 AM UTC)..."

CRON_CMD="0 10 * * * /home/claude/autopost/venv/bin/python3 /home/claude/autopost/run.py >> /home/claude/autopost/logs/cron.log 2>&1"

# Add to crontab if not already there
(crontab -l 2>/dev/null | grep -v "autopost/run.py"; echo "$CRON_CMD") | crontab -

echo ""
echo "Current crontab:"
crontab -l

# ── CREATE SIMPLE WEB SERVER FOR VIDEO HOSTING ────────────────
# Instagram requires a public URL to upload videos
echo ""
echo "Setting up simple video file server on port 8080..."

cat > /home/claude/autopost/serve_videos.py << 'PYEOF'
"""Simple HTTP server to serve video files for Instagram upload."""
import http.server
import socketserver
import os

PORT = 8080
DIRECTORY = "/home/claude/autopost/output"

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)
    def log_message(self, format, *args):
        pass  # Suppress logs

os.chdir(DIRECTORY)
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Serving videos at http://0.0.0.0:{PORT}")
    httpd.serve_forever()
PYEOF

# Create systemd service for the video server
cat > /etc/systemd/system/autopost-server.service << 'EOF'
[Unit]
Description=AutoPost Video File Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/home/claude/autopost
ExecStart=/home/claude/autopost/venv/bin/python3 /home/claude/autopost/serve_videos.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable autopost-server
systemctl start autopost-server

# ── FIREWALL ─────────────────────────────────────────────────
if command -v ufw &> /dev/null; then
    ufw allow 8080/tcp
    echo "Port 8080 opened in firewall"
fi

# ── FINAL TEST ────────────────────────────────────────────────
echo ""
echo "=================================================="
echo "  SETUP COMPLETE"
echo "=================================================="
echo ""
echo "Next steps:"
echo ""
echo "  1. Edit /home/claude/autopost/config/config.py"
echo "     → Add your OPENAI_API_KEY"
echo "     → Add your TIKTOK_ACCESS_TOKEN"
echo "     → Add your INSTAGRAM_ACCESS_TOKEN"
echo "     → Add your Pexels API key (optional, for backgrounds)"
echo ""
echo "  2. Test the pipeline (dry run — no posting):"
echo "     source /home/claude/autopost/venv/bin/activate"
echo "     python3 /home/claude/autopost/run.py --dry-run"
echo ""
echo "  3. Test with a specific topic:"
echo "     python3 run.py --dry-run --topic 'How to use Gemini AI to learn English'"
echo ""
echo "  4. Run live (will post to all platforms):"
echo "     python3 /home/claude/autopost/run.py"
echo ""
echo "  5. Cron is set — pipeline runs daily at 10:00 AM UTC"
echo "     Check logs: tail -f /home/claude/autopost/logs/cron.log"
echo ""
echo "  Your Vultr server IP for video hosting:"
curl -s ifconfig.me 2>/dev/null || echo "  (run: curl ifconfig.me)"
echo ""
