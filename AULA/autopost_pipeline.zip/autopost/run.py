"""
AutoPost Master Orchestrator
Runs the full pipeline: Trend → Script → Voice → Video → Post
Schedule with cron: 0 10 * * * /usr/bin/python3 /home/claude/autopost/run.py
G6 LLC · Pablo Nogueira Grossi · Newark, NJ
"""

import os
import sys
import json
import datetime
import logging
import traceback

sys.path.append('/home/claude/autopost')

from config.config import OUTPUT_DIR, LOGS_DIR
from scripts.01_scrape_trends   import get_best_trend
from scripts.02_generate_script import generate_script, save_script
from scripts.03_generate_voiceover import generate_voiceover_sync, prepare_script_for_tts
from scripts.04_render_video    import download_background_video, render_video
from scripts.05_post_video      import post_everywhere

# ── SETUP ──────────────────────────────────────────────────────
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(LOGS_DIR,   exist_ok=True)

log_file = os.path.join(LOGS_DIR, f"run_{datetime.date.today()}.log")
logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

# Your Instagram user ID (get from Meta Graph API)
IG_USER_ID = "your_instagram_user_id"


def run_pipeline(dry_run: bool = False) -> dict:
    """
    Executes the full AutoPost pipeline.
    dry_run=True: generates everything but does not post.
    """
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    print(f"\n{'='*55}")
    print(f"  AutoPost Pipeline — {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"  G6 LLC · @guru.oenglish · @pablogrow2026")
    print(f"{'='*55}\n")

    results = {"timestamp": ts, "status": "running"}

    try:
        # ── STEP 1: SCRAPE TREND ────────────────────────────────
        print("STEP 1/5 — Scraping trends...")
        trend = get_best_trend()
        results["trend"] = trend
        print(f"  Topic: {trend['topic']}")
        print(f"  Source: {trend['source']}\n")

        # ── STEP 2: GENERATE SCRIPT ─────────────────────────────
        print("STEP 2/5 — Generating script with GPT-4o-mini...")
        script_data = generate_script(trend)
        results["script"] = script_data

        script_path = os.path.join(OUTPUT_DIR, f"script_{ts}.json")
        save_script(script_data, script_path)

        print(f"\n  --- SCRIPT PREVIEW ---")
        for i, line in enumerate(script_data["lines"], 1):
            print(f"  {i}. {line}")
        print()

        # ── STEP 3: GENERATE VOICEOVER ──────────────────────────
        print("STEP 3/5 — Generating voiceover (edge-tts, free)...")
        audio_path = os.path.join(OUTPUT_DIR, f"voice_{ts}.mp3")
        tts_text   = prepare_script_for_tts(script_data["lines"])

        generate_voiceover_sync(tts_text, audio_path)
        results["audio_path"] = audio_path
        print(f"  Audio: {audio_path}\n")

        # ── STEP 4: RENDER VIDEO ────────────────────────────────
        print("STEP 4/5 — Rendering video (FFmpeg, local)...")

        # Download/select background
        bg_term = "technology abstract" if "ai" in trend["topic"].lower() else "nature abstract"
        bg_path = download_background_video(bg_term)

        video_path = os.path.join(OUTPUT_DIR, f"video_{ts}.mp4")
        render_video(
            background_path = bg_path,
            audio_path      = audio_path,
            script_lines    = script_data["lines"],
            output_path     = video_path,
            topic           = trend["topic"],
        )
        results["video_path"] = video_path
        print(f"  Video: {video_path}\n")

        # ── STEP 5: POST ─────────────────────────────────────────
        if dry_run:
            print("STEP 5/5 — DRY RUN: skipping post")
            results["post_results"] = {"status": "dry_run"}
        else:
            print("STEP 5/5 — Posting to TikTok, YouTube, Instagram...")
            post_results = post_everywhere(video_path, script_data, IG_USER_ID)
            results["post_results"] = post_results

        # ── SAVE RUN LOG ─────────────────────────────────────────
        results["status"] = "success"
        log_path = os.path.join(LOGS_DIR, f"run_{ts}.json")
        with open(log_path, 'w') as f:
            json.dump(results, f, indent=2, ensure_ascii=False, default=str)

        print(f"\n{'='*55}")
        print(f"  PIPELINE COMPLETE")
        print(f"  Topic:  {trend['topic'][:55]}")
        print(f"  Video:  {os.path.basename(video_path)}")
        print(f"  Log:    {log_path}")
        print(f"{'='*55}\n")

        logging.info(f"Pipeline complete: {trend['topic'][:60]}")
        return results

    except Exception as e:
        error_msg = traceback.format_exc()
        logging.error(f"Pipeline failed: {error_msg}")
        results["status"] = "error"
        results["error"] = error_msg
        print(f"\n[ERROR] Pipeline failed:\n{error_msg}")
        return results


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="AutoPost Pipeline")
    parser.add_argument("--dry-run", action="store_true",
                        help="Generate video but do not post")
    parser.add_argument("--topic", type=str, default=None,
                        help="Override trend with a specific topic")
    args = parser.parse_args()

    if args.topic:
        # Override trend scraping with a specific topic
        from scripts.02_generate_script import generate_script
        custom_trend = {"topic": args.topic, "source": "manual", "score": 100}
        # Monkey-patch get_best_trend
        import scripts.s01_scrape_trends as s1
        s1.get_best_trend = lambda: custom_trend

    run_pipeline(dry_run=args.dry_run)
